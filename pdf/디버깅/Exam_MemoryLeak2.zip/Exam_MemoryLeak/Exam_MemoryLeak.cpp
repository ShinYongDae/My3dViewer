﻿#include "pch.h"
#include <Windows.h>
#include <iostream>

#define _CRTDBG_MAP_ALLOC
#include <cstdlib>
#include <crtdbg.h>

#ifdef _DEBUG
#define new new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
#endif

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	_CrtMemState s1;
	_CrtMemCheckpoint(&s1);
	_CrtMemDumpStatistics(&s1);

	byte* ptr = new byte[100];

	//delete[] ptr;

	_CrtMemState s2;
	_CrtMemCheckpoint(&s2);
	_CrtMemDumpStatistics(&s2);

	_CrtMemState s3;
	if (_CrtMemDifference(&s3, &s1, &s2) == true)
		_CrtMemDumpStatistics(&s3);
}